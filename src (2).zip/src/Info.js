import React from 'react';

const Info = ({ cast }) => {
  return (
    <div>
      <p><strong>출연진: </strong>{cast}</p>
    </div>
  );
};

export default Info;
