import React from 'react';
import MovieDetail from './MovieDetail';
import "./App.css";


function App() {
  return (
    <div className="App">
      <MovieDetail />
      <footer/>
    </div>
  );
}

export default App;